﻿
Imports MySql.Data.MySqlClient

Module Module1
    Public connection As New MySqlConnection("server = localhost; user = root; password =; database = rad_base;")
End Module
