﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Client
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        GroupBox11 = New GroupBox()
        Button88 = New Button()
        Buttonproo = New Button()
        Buttonvenn = New Button()
        Button6 = New Button()
        Button5 = New Button()
        Label5 = New Label()
        DataGridView = New DataGridView()
        Button44 = New Button()
        Button33 = New Button()
        Button22 = New Button()
        Button11 = New Button()
        TextBox44 = New TextBox()
        PictureBox11 = New PictureBox()
        TextBox33 = New TextBox()
        Label4 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        TextBox22 = New TextBox()
        TextBox11 = New TextBox()
        Photo = New Label()
        Label1 = New Label()
        GroupBox11.SuspendLayout()
        CType(DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox11
        ' 
        GroupBox11.BackColor = SystemColors.ActiveCaption
        GroupBox11.BackgroundImageLayout = ImageLayout.Stretch
        GroupBox11.Controls.Add(Button88)
        GroupBox11.Controls.Add(Buttonproo)
        GroupBox11.Controls.Add(Buttonvenn)
        GroupBox11.Controls.Add(Button6)
        GroupBox11.Controls.Add(Button5)
        GroupBox11.Controls.Add(Label5)
        GroupBox11.Controls.Add(DataGridView)
        GroupBox11.Controls.Add(Button44)
        GroupBox11.Controls.Add(Button33)
        GroupBox11.Controls.Add(Button22)
        GroupBox11.Controls.Add(Button11)
        GroupBox11.Controls.Add(TextBox44)
        GroupBox11.Controls.Add(PictureBox11)
        GroupBox11.Controls.Add(TextBox33)
        GroupBox11.Controls.Add(Label4)
        GroupBox11.Controls.Add(Label2)
        GroupBox11.Controls.Add(Label3)
        GroupBox11.Controls.Add(TextBox22)
        GroupBox11.Controls.Add(TextBox11)
        GroupBox11.Controls.Add(Photo)
        GroupBox11.Controls.Add(Label1)
        GroupBox11.Font = New Font("Segoe UI Semibold", 15F, FontStyle.Bold)
        GroupBox11.Location = New Point(-29, 6)
        GroupBox11.Name = "GroupBox11"
        GroupBox11.Size = New Size(1885, 1043)
        GroupBox11.TabIndex = 10
        GroupBox11.TabStop = False
        GroupBox11.Text = "."
        ' 
        ' Button88
        ' 
        Button88.Font = New Font("Segoe UI", 20F)
        Button88.Location = New Point(1564, 110)
        Button88.Name = "Button88"
        Button88.Size = New Size(60, 57)
        Button88.TabIndex = 21
        Button88.Text = "X"
        Button88.UseVisualStyleBackColor = True
        ' 
        ' Buttonproo
        ' 
        Buttonproo.Font = New Font("Segoe UI", 20F)
        Buttonproo.Location = New Point(1208, 21)
        Buttonproo.Name = "Buttonproo"
        Buttonproo.Size = New Size(213, 56)
        Buttonproo.TabIndex = 19
        Buttonproo.Text = "PRODUITS"
        Buttonproo.UseVisualStyleBackColor = True
        ' 
        ' Buttonvenn
        ' 
        Buttonvenn.Font = New Font("Segoe UI", 20F)
        Buttonvenn.Location = New Point(1465, 21)
        Buttonvenn.Name = "Buttonvenn"
        Buttonvenn.Size = New Size(213, 56)
        Buttonvenn.TabIndex = 18
        Buttonvenn.Text = "VENTES"
        Buttonvenn.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button6.Location = New Point(463, 306)
        Button6.Name = "Button6"
        Button6.Size = New Size(67, 65)
        Button6.TabIndex = 17
        Button6.Text = "-"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(463, 145)
        Button5.Name = "Button5"
        Button5.Size = New Size(67, 65)
        Button5.TabIndex = 16
        Button5.Text = "+"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 34F)
        Label5.Location = New Point(443, 21)
        Label5.Name = "Label5"
        Label5.Size = New Size(426, 76)
        Label5.TabIndex = 15
        Label5.Text = "PARTIE CLIENTS"
        ' 
        ' DataGridView
        ' 
        DataGridViewCellStyle2.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        DataGridViewCellStyle2.SelectionBackColor = Color.Thistle
        DataGridViewCellStyle2.SelectionForeColor = Color.Black
        DataGridView.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle2
        DataGridView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.BackgroundColor = SystemColors.ControlDarkDark
        DataGridView.BorderStyle = BorderStyle.None
        DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView.Location = New Point(602, 306)
        DataGridView.MultiSelect = False
        DataGridView.Name = "DataGridView"
        DataGridView.RowHeadersWidth = 51
        DataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGridView.Size = New Size(1022, 633)
        DataGridView.TabIndex = 14
        ' 
        ' Button44
        ' 
        Button44.BackColor = Color.Red
        Button44.Font = New Font("Segoe UI", 20F)
        Button44.ForeColor = SystemColors.ActiveCaptionText
        Button44.Location = New Point(267, 853)
        Button44.Name = "Button44"
        Button44.Size = New Size(205, 56)
        Button44.TabIndex = 13
        Button44.Text = "SUPPRIMER"
        Button44.UseVisualStyleBackColor = False
        ' 
        ' Button33
        ' 
        Button33.BackColor = Color.Goldenrod
        Button33.Font = New Font("Segoe UI", 20F)
        Button33.Location = New Point(267, 758)
        Button33.Name = "Button33"
        Button33.Size = New Size(205, 56)
        Button33.TabIndex = 12
        Button33.Text = "MODIFIER"
        Button33.UseVisualStyleBackColor = False
        ' 
        ' Button22
        ' 
        Button22.Font = New Font("Segoe UI", 20F)
        Button22.Location = New Point(33, 853)
        Button22.Name = "Button22"
        Button22.Size = New Size(213, 56)
        Button22.TabIndex = 11
        Button22.Text = "ACTUALISER"
        Button22.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.BackColor = Color.LavenderBlush
        Button11.Font = New Font("Segoe UI", 20F)
        Button11.Location = New Point(33, 758)
        Button11.Name = "Button11"
        Button11.Size = New Size(213, 56)
        Button11.TabIndex = 10
        Button11.Text = "AJOUTER"
        Button11.UseVisualStyleBackColor = False
        ' 
        ' TextBox44
        ' 
        TextBox44.BackColor = Color.LightYellow
        TextBox44.Font = New Font("Segoe UI", 20F)
        TextBox44.Location = New Point(885, 195)
        TextBox44.Name = "TextBox44"
        TextBox44.PlaceholderText = "Tapez ici"
        TextBox44.Size = New Size(664, 52)
        TextBox44.TabIndex = 9
        TextBox44.TextAlign = HorizontalAlignment.Center
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        PictureBox11.BackColor = SystemColors.ControlDarkDark
        PictureBox11.Location = New Point(91, 110)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(329, 303)
        PictureBox11.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox11.TabIndex = 0
        PictureBox11.TabStop = False
        ' 
        ' TextBox33
        ' 
        TextBox33.BackColor = SystemColors.Info
        TextBox33.Font = New Font("Segoe UI", 20F)
        TextBox33.Location = New Point(33, 670)
        TextBox33.Name = "TextBox33"
        TextBox33.PlaceholderText = "Tapez ici"
        TextBox33.Size = New Size(439, 52)
        TextBox33.TabIndex = 8
        TextBox33.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 22F)
        Label4.Location = New Point(201, 409)
        Label4.Name = "Label4"
        Label4.Size = New Size(111, 50)
        Label4.TabIndex = 5
        Label4.Text = "NOM"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 22F)
        Label2.Location = New Point(172, 621)
        Label2.Name = "Label2"
        Label2.Size = New Size(172, 50)
        Label2.TabIndex = 3
        Label2.Text = "ADRESSE"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 22F)
        Label3.Location = New Point(172, 517)
        Label3.Name = "Label3"
        Label3.Size = New Size(173, 50)
        Label3.TabIndex = 4
        Label3.Text = "PRENOM"
        ' 
        ' TextBox22
        ' 
        TextBox22.BackColor = SystemColors.Info
        TextBox22.Font = New Font("Segoe UI", 20F)
        TextBox22.Location = New Point(33, 566)
        TextBox22.Name = "TextBox22"
        TextBox22.PlaceholderText = "Tapez ici"
        TextBox22.Size = New Size(439, 52)
        TextBox22.TabIndex = 7
        TextBox22.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox11
        ' 
        TextBox11.AccessibleDescription = ""
        TextBox11.BackColor = SystemColors.Info
        TextBox11.Font = New Font("Segoe UI", 20F)
        TextBox11.Location = New Point(33, 462)
        TextBox11.Name = "TextBox11"
        TextBox11.PlaceholderText = "Tapez ici"
        TextBox11.Size = New Size(439, 52)
        TextBox11.TabIndex = 6
        TextBox11.TextAlign = HorizontalAlignment.Center
        ' 
        ' Photo
        ' 
        Photo.AutoSize = True
        Photo.Font = New Font("Segoe UI", 22F)
        Photo.Location = New Point(201, 57)
        Photo.Name = "Photo"
        Photo.Size = New Size(140, 50)
        Photo.TabIndex = 1
        Photo.Text = "PHOTO"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 22F)
        Label1.Location = New Point(602, 194)
        Label1.Name = "Label1"
        Label1.Size = New Size(220, 50)
        Label1.TabIndex = 2
        Label1.Text = "RECHERCHE"
        ' 
        ' Client
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1826, 1055)
        Controls.Add(GroupBox11)
        Name = "Client"
        Text = "Client"
        GroupBox11.ResumeLayout(False)
        GroupBox11.PerformLayout()
        CType(DataGridView, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents Button88 As Button
    Friend WithEvents Buttonproo As Button
    Friend WithEvents Buttonvenn As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents Button44 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents TextBox44 As TextBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Photo As Label
    Friend WithEvents Label1 As Label
End Class
