#include <stdio.h>
#include <stdlib.h>

#include "Parser.h"


void f_write_in(char *path, struct Information *info)
{
    // Ouvre le fichier en mode écriture ('w')
    FILE *file = fopen(path, "w");
    
    // Vérifie si l'ouverture du fichier a réussi
    if (file == NULL)
    {
        printf("[FILER - ERROR] : file not found at %s", path);
        exit(1);
    }

    // Écrit la représentation JSON des informations dans le fichier
    fprintf(file, "%s", p_info_parse(info));

    // Ferme le fichier
    fclose(file);
}

// Lit les informations depuis un fichier.
struct Information *f_read_from(char *path)
{
    // Ouvre le fichier en mode lecture ('r')
    FILE *file = fopen(path, "r");

    // Vérifie si l'ouverture du fichier a réussi
    if (file == NULL)
    {
        printf("[FILER - ERROR] : file not found at %s", path);
        exit(1);
    }

    // Lit le contenu du fichier dans une chaîne de caractères
    char message[MAX_MESSAGE_LENGTH] = "";
    fscanf(file, "%s", message);

    // Ferme le fichier
    fclose(file);

    // Parse le message JSON pour obtenir une structure Information
    return p_info_read(message);
}
