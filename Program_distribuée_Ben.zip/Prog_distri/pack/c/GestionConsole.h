#include "Sys_objects.h"

void error(const char *msg)
{
	perror(msg);
	exit(1);
}

void *handle_command_message()
{
	while (1)
	{
		printf("Gestion Console reading...\n");
		char buffer[BUFFER_SIZE];
		bzero(buffer, BUFFER_SIZE);
		n = read(cmd_c_sockfd, buffer, BUFFER_SIZE);
		if (n < 0)
			error("[GESTION_CONSOLE - READING_ERROR] : Impossible de lire la requete du module [COMMANDE_CONSOLE]\n");
		printf("Message : %s \n", buffer);
		n = write(ct_socket, buffer, strlen(buffer));
		if (n < 0)
			error("[GESTION_CONSOLE - WRITING_ERROR] : Impossible d'envoyer une requete vers le module [COMMUNICATION_TEMPERATURE]\n");
	}
	return NULL;
}

void *handle_t_check_message()
{
	while (1)
	{
		socklen_t len;
		struct Information *info = malloc(sizeof(struct Information));
		info->temperature = NO_TEMPERATURE;
		char *message = p_info_parse(info);
		n = write(ct_socket, message, strlen(message));
		if (n < 0)
			error("[GESTION CONSOLE - ERROR] : Transfert impossible vers [COMMUNICATION_TEMPERATURE]\n");
			sleep(REFRESH_TIME);
		for (int i = 0; i < MAX_THERMOMETRE; i++)
		{
			if (thermometres[i] != NULL)
			{
				n = read(ct_socket, message, strlen(message));
				if (n < 0)
					error("[GESTION CONSOLE - ERROR] : Reception impossible de [COMMUNICATION_TEMPERATURE]\n");
				snprintf(message, sizeof(char[MAX_MESSAGE_LENGTH]), " | therm = %s", thermometres[i]->state);
				len = sizeof(rmi_cliaddr);
				n = sendto(rmi_sockfd, (char *)message, BUFFER_SIZE,
						   MSG_WAITALL, (struct sockaddr *)&rmi_cliaddr,
						   len);
				n = send(ctl_c_sockfd, (char *)message, sizeof(message), 0);
				if (n < 0)
					error("[GESTION CONSOLE - ERROR] : Envoie impossible vers [CONTROLE_CONSOLE]\n");
			}
		}
		free(info);
		sleep(REFRESH_TIME);
	}
	return NULL;
}

void *handle_rmi_connection()
{
	do
	{
		char buffer[BUFFER_SIZE];
		char *hello = (char *)"GESTION CONSOLE v1.0 \r\n";
		printf("[GESTION CONSOLE - INFO] : Connection UDP au module [SERVER_RMI], demarree sur le port - %d.\n", RMI_SERVER_PORT);
		if ((rmi_sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		{
			perror("[GESTION CONSOLE - ERROR] : Impossible de se connecter au module [SERVER_RMI].\n");
			exit(EXIT_FAILURE);
		}
		memset(&rmi_servaddr, 0, sizeof(rmi_servaddr));
		memset(&rmi_cliaddr, 0, sizeof(rmi_cliaddr));
		rmi_servaddr.sin_family = AF_INET;
		rmi_servaddr.sin_addr.s_addr = INADDR_ANY;
		rmi_servaddr.sin_port = htons(RMI_SERVER_PORT);
		if (bind(rmi_sockfd, (const struct sockaddr *)&rmi_servaddr, sizeof(rmi_servaddr)) < 0)
		{
			perror("[GESTION CONSOLE - ERROR] : Attribution de la connection echouee avec le module [SERVER_RMI].\n");
			exit(EXIT_FAILURE);
		}
		int len, n;
		printf("[GESTION CONSOLE - INFO] : Connection ouverte pour le module [SERVER_RMI].\n");
		sendto(rmi_sockfd, (const char *)hello, strlen(hello), MSG_CONFIRM, (const struct sockaddr *)&rmi_cliaddr, len);
		len = sizeof(rmi_cliaddr);
		sleep(500);
	} while (rmi_sockfd < 0);
	return NULL;
}

void *handle_ctl_c_connection()
{
	// perror("GC Debug ctl");
	int sockfd, portno, n;
	char buffer[BUFFER_SIZE];
	struct sockaddr_in serv_addr, cli_addr;
	socklen_t clilen;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		error("[GESTION_CONSOLE - SOCKET_ERROR] : Impossible de se connecter avec le module [CONTROLE_CONSOLE]\n");

	bzero((char *)&serv_addr, sizeof(serv_addr));
	portno = CONTROL_CONSOLE_PORT;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
		error("[GESTION_CONSOLE - BINDING_ERROR] : Impossible de se connecter avec le module [CONTROLE_CONSOLE]\n");

	listen(sockfd, 1);
	clilen = sizeof(cli_addr);

	ctl_c_sockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
	if (ctl_c_sockfd < 0)
		error("[GESTION_CONSOLE - ACCEPT_ERROR] : Impossible d'accepter la connection avec le module [CONTROLE_CONSOLE]\n");
	printf("[GESTION_CONSOLE - INFO] : Connection etablie avec le module [CONTROLE_CONSOLE]\n");
	pthread_t t_check_id;

	pthread_create(&t_check_id, NULL, handle_t_check_message, NULL);
	pthread_join(t_check_id, NULL);
	return NULL;
}

void *handle_cmd_c_connection()
{
	int sockfd, portno, n;
	char buffer[BUFFER_SIZE];
	struct sockaddr_in serv_addr, cli_addr;
	socklen_t clilen;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		error("[GESTION_CONSOLE - SOCKET_ERROR] : Impossible de se connecter avec le module [COMMANDE_CONSOLE]\n");

	bzero((char *)&serv_addr, sizeof(serv_addr));
	portno = COMMAND_CONSOLE_PORT;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
		error("[GESTION_CONSOLE - BINDING_ERROR] : Impossible de se connecter avec le module [COMMANDE_CONSOLE]\n");

	listen(sockfd, 1);
	clilen = sizeof(cli_addr);

	cmd_c_sockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
	if (cmd_c_sockfd < 0)
		error("[GESTION_CONSOLE - ACCEPT_ERROR] : Impossible d'accepter la connection avec le module [COMMANDE_CONSOLE]\n");
	printf("[GESTION_CONSOLE - INFO] : Connection etablie avec le module [COMMANDE_CONSOLE]\n");
	pthread_t cmd_console_id;
	pthread_create(&cmd_console_id, NULL, handle_command_message, NULL);
	pthread_join(cmd_console_id, NULL);
	close(cmd_c_sockfd);
	close(sockfd);
	return NULL;
}
