struct Information{
    const char* multicast;
    const char* piece;
    int valeur;
    double temperature;
    char type;
};