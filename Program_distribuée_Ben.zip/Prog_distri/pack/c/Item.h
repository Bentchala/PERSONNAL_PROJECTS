struct Item{
    char* multicast;
    const char* piece;
    int socket;
    const char* type;
    char* state;
};