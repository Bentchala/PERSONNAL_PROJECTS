#include "../../pack/c/CommunicationTemperature.h"

int main()
{
    // Déclaration des variables liées au serveur
    int sockfd, newsockfd, portno, n;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t clilen;

    // Création du socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
        error("[COMMUNICATION_TEMPERATURE - SOCKETOPEN_ERROR] : Impossible de communiquer avec le module [GESTION_CONSOLE].\n");

    // Initialisation de la structure d'adresse du serveur
    bzero((char *)&serv_addr, sizeof(serv_addr));
    portno = SYSTEM_PORT;
    printf("[COMMUNICATION_TEMPERATURE - INFO] : En exécution sur le port # %d.\n", portno);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    // Association du socket avec l'adresse du serveur
    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        error("[COMMUNICATION_TEMPERATURE - BINDING_ERROR] : Impossible de communiquer avec le module [GESTION_CONSOLE].\n");

    // Mise en attente des connexions entrantes
    listen(sockfd, 1);
    clilen = sizeof(cli_addr);

    // Acceptation d'une connexion entrante
    newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
    if (newsockfd < 0)
        error("[COMMUNICATION_TEMPERATURE - ACCEPT_ERROR] : Impossible d'établir la connexion avec le module [GESTION_CONSOLE].\n");

    // Assignation du nouveau socket à une variable globale (peut-être déclarée ailleurs dans le code)
    gc_socket = newsockfd;

    // Création des threads pour gérer les connexions
    pthread_t chauffageId, thermometreId;
    pthread_create(&thermometreId, NULL, handle_t_connection, NULL);
    pthread_create(&chauffageId, NULL, handle_c_connection, NULL);

    // Boucle principale de traitement des données
    while (1)
    {
        // Initialisation du tampon de réception
        bzero(buffer, BUFFER_SIZE);

        // Lecture des données du socket
        n = read(newsockfd, buffer, BUFFER_SIZE);
        if (n < 0)
            error("[COMMUNICATION_TEMPERATURE - READING_ERROR] : Impossible de recevoir des données du module [GESTION_CONSOLE].\n");

        // Traitement des informations lues
        struct Information *info = p_info_read(buffer);

        // Sélection du traitement en fonction de la température reçue
        if (info->temperature == NO_TEMPERATURE)
        {
            handle_t_send_message(info);
        }
        else
        {
            handle_c_send_message(info);
        }
    }

    // Annulation des threads à la fin de l'exécution
    pthread_cancel(chauffageId);
    pthread_cancel(thermometreId);

    // Fermeture des sockets
    close(t_sockfd);
    close(c_sockfd);
    close(newsockfd);
    close(sockfd);

    return 0;
}
