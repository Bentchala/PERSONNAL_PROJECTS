#include "../../pack/c/GestionConsole.h"

int main()
{
    // Déclaration des variables liées au client
    int sockfd, portno, n;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in serv_addr;
    struct hostent *server;

    // Configuration du port pour la communication avec le module [COMMUNICATION_TEMPERATURE]
    portno = SYSTEM_PORT;

    // Création du socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
        error("[GESTION_CONSOLE - ERROR] : Impossible de se connecter avec le module [COMMUNICATION_TEMPERATURE]\n");

    // Résolution de l'adresse IP du serveur (localhost dans cet exemple)
    server = gethostbyname("localhost");
    if (server == NULL)
    {
        fprintf(stderr, "[GESTION_CONSOLE - ERROR] : Impossible de trouver l'hôte\n");
        exit(1);
    }

    // Initialisation de la structure d'adresse du serveur
    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);

    // Connexion au serveur [COMMUNICATION_TEMPERATURE]
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        error("[GESTION_CONSOLE - ERROR] : Impossible de se connecter avec le module [COMMUNICATION_TEMPERATURE]\n");

    // Assignation du socket à une variable globale (peut-être déclarée ailleurs dans le code)
    ct_socket = sockfd;

    // Création des threads pour gérer les connexions
    pthread_t rmi_id, ctl_c_id, cmd_c_id, h_t_check_id;
    pthread_create(&rmi_id, NULL, handle_rmi_connection, NULL);
    pthread_create(&ctl_c_id, NULL, handle_ctl_c_connection, NULL);
    pthread_create(&cmd_c_id, NULL, handle_cmd_c_connection, NULL);
    pthread_create(&h_t_check_id, NULL, handle_t_check_message, NULL);

    // Attente de la terminaison des threads
    pthread_join(rmi_id, NULL);
    pthread_join(ctl_c_id, NULL);
    pthread_join(cmd_c_id, NULL);
    pthread_join(h_t_check_id, NULL);

    // Fermeture des sockets
    // close(ct_socket);  // La fermeture dépend de l'architecture globale du programme
    // close(sockfd);      // Peut être fermé ici ou dans un autre contexte selon les besoins

    return 0;
}
