package systeme.java;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
import pack.java.Constants;
import systeme.java.metier.CtlInterface;

public class ServerRMI implements CtlInterface {
    Scanner sc = new Scanner(System.in);

    public ServerRMI() {
    }

    // Méthode à distance pour récupérer des informations
    public String printInformations() {
        String message = "";
        DatagramSocket socket = null;
        try {
            // Création d'une socket pour la communication UDP
            socket = new DatagramSocket();
            byte[] buffer = new byte[Constants.BUFFER_SIZE];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);

            // Réception du message provenant du module [COMMUNICATION_TEMPERATURE]
            socket.receive(response);
            message = new String(buffer, 0, response.getLength());

            // Ajout d'une pause pour simuler le rafraîchissement des informations
            Thread.sleep(Constants.REFRESH_TIME);
        } catch (SocketTimeoutException ex) {
            System.out.println("[SERVEUR_RMI - TIMEOUT_ERROR] : " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("[SERVEUR_RMI - CLIENT_ERROR] : " + ex.getMessage());
        } catch (InterruptedException ex) {
            System.out.println("[SERVEUR_RMI - INTERRUPTED_ERROR] : " + ex.getMessage());
        } finally {
            // Fermeture de la socket après utilisation
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
        return message + "\n";
    }

    public static void main(String args[]) {
        try {
            // Création d'une instance du serveur RMI
            ServerRMI obj = new ServerRMI();

            // Exportation de l'objet serveur en tant que stub RMI
            CtlInterface stub = (CtlInterface) UnicastRemoteObject.exportObject(obj, 0);

            // Création et enregistrement du registre RMI sur le port spécifié
            Registry registry = LocateRegistry.createRegistry(Constants.CLIENT_RMI_PORT);
            registry.rebind(Constants.CONNECTION_POINT, stub);

            // Affichage du message de démarrage
            System.err.println("[SERVEUR_RMI - INFO] : Serveur démarré sur le port - " + Constants.CLIENT_RMI_PORT);
        } catch (Exception e) {
            System.err.println("[SERVEUR_RMI - RMI_ERROR] : " + e.getMessage());
        }
    }
}
