#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>
#define AF_INET PF_INET

#include "../../pack/c/Constants.h"

// Tout ce dont on a besoin pour la connection avec le multicast de la piece
int pieceSockfd, piecePortno, pieceN;
char pieceBuffer[BUFFER_SIZE];
struct sockaddr_in pieceServ_addr;
struct hostent *pieceSocket;
// Tout ce dont on a besoin pour la connection avec le systeme de gestion
// de la température
int systemeSockfd, systemePortno, systemeN;
char systemeBuffer[BUFFER_SIZE];
struct sockaddr_in systemeServ_addr;
struct hostent *systemeSocket;

socklen_t len;

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

void *handleMessageFromSystem()
{
    while (1)
    {
        int n;
        // Message attendu et reçu du système
        sleep(5000);
        systemeN = read(systemeSockfd, systemeBuffer, strlen(systemeBuffer));
        printf("[CHAUFFAGE - INFO] : %s\n", systemeBuffer);
        if (systemeN < 0)
            error("[THERMOMETRE - ERROR] : Erreur lors de la réception du message du systeme.");
        printf("Message from system : %s\n", systemeBuffer);
        // Message envoyé à la pièce
        sendto(pieceSockfd, (const char *)systemeBuffer, strlen(systemeBuffer),
               MSG_CONFIRM, (const struct sockaddr *)&pieceServ_addr,
               sizeof(pieceServ_addr));
        // Message attendu et reçu de la pièce
        // pieceN = recvfrom(pieceSockfd, (char *)systemeBuffer, BUFFER_SIZE,
        //                   MSG_WAITALL, (struct sockaddr *)&pieceServ_addr,
        //                   &len);
        // if (pieceN < 0)
        //     error("[THERMOMETRE - ERROR] : Erreur lors de la reception du message de la piece.");
        // // Message envoyé au système
        // systemeN = write(systemeSockfd, systemeBuffer, BUFFER_SIZE);
        // if (systemeN < 0)
        //     error("[THERMOMETRE - ERROR] : Erreur lors de l'envoie du message au systeme.");
    }
    return NULL;
}
void *handleMessageFromRoom()
{
    while (1)
    {
        // bzero(systemeBuffer, BUFFER_SIZE);
        // fgets(systemeBuffer, BUFFER_SIZE, stdin);
        // Message attendu et reçu de la pièce
        pieceN = recvfrom(pieceSockfd, (char *)systemeBuffer, BUFFER_SIZE,
                          MSG_WAITALL, (struct sockaddr *)&pieceServ_addr,
                          &len);
        if (pieceN < 0)
            error("[THERMOMETRE - ERROR] : Erreur lors de la reception du message de la piece.");
        // Message envoyé au système
        systemeN = write(systemeSockfd, systemeBuffer, BUFFER_SIZE);
        if (systemeN < 0)
            error("[THERMOMETRE - ERROR] : Erreur lors de l'envoie du message au systeme.");
    }
    return NULL;
}

int main()
{
    //--- Tentative de connection à la piece ---//
    printf("[THERMOMETRE - INFO] : Connection au multicast de la piece en cours...\n");

    if ((pieceSockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        error("[THERMOMETRE - ERROR] : Impossible de se connecter au multicast de la piece.\n");
    }
    pieceSocket = gethostbyname(MULTICAST_HOST);
    if (pieceSocket == NULL)
    {
        fprintf(stderr, "[THERMOMETRE - ERROR] : L'adresse ip du multicast n'est pas valide.\n");
        exit(1);
    }
    memset(&pieceServ_addr, 0, sizeof(pieceServ_addr));

    // Filling server information
    pieceServ_addr.sin_family = AF_INET;
    pieceServ_addr.sin_port = htons(MULTICAST_PORT);
    pieceServ_addr.sin_addr.s_addr = INADDR_ANY;

    printf("[THERMOMETRE - INFO] : Connection au multicast de la piece reussie...\n");

    //--- Tentative de connection au systeme de gestion de temperature ---//

    printf("[THERMOMETRE - INFO] : Connection au systeme de gestion de temperature cours...\n");
    // Création du socket au systeme de gestion de temperature
    systemePortno = THERMOMETRE_TO_SYSTEM_PORT;
    systemeSockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (systemeSockfd < 0)
        error("[THERMOMETRE - ERROR] : Impossible de se connecter au systeme de gestion de temperature.\n");
    systemeSocket = gethostbyname("localhost");
    if (systemeSocket == NULL)
    { // Si l'ip n'est pas valide
        fprintf(stderr, "[THERMOMETRE - ERROR] : L'adresse ip du systeme de gestion de temperature n'est pas valide.\n");
        exit(1);
    }
    bzero((char *)&systemeServ_addr, sizeof(systemeServ_addr));
    systemeServ_addr.sin_family = AF_INET;
    bcopy((char *)systemeSocket->h_addr, (char *)&systemeServ_addr.sin_addr.s_addr, systemeSocket->h_length);
    systemeServ_addr.sin_port = htons(systemePortno);
    // Pas de connection au niveau du client
    if (connect(systemeSockfd, (struct sockaddr *)&systemeServ_addr, sizeof(systemeServ_addr)) < 0)
        error("[THERMOMETRE - ERROR] : Impossible de se connecter au systeme de gestion de temperature.\n");

    printf("[THERMOMETRE - INFO] : Connection au systeme de gestion de temperature de la piece reussie...\n");

    // Création de thread pour gérer la communication
    // d'une part, venant du système, et d'autre part,
    // venant de la piece
    pthread_t systemeId, pieceId;
    pthread_create(&systemeId, NULL, handleMessageFromSystem, NULL);
    pthread_create(&pieceId, NULL, handleMessageFromRoom, NULL);
    pthread_join(systemeId, NULL);
    pthread_join(pieceId, NULL);
    close(pieceSockfd);
    close(systemeSockfd);
    return 0;
}
