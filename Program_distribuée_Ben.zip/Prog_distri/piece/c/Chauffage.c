#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#define AF_INET PF_INET

#include "../../pack/c/Constants.h"

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int main()
{
    //--- Tentative de connection à la piece ---//
    printf("[CHAUFFAGE - INFO] : Connection au multicast de la piece en cours...\n");
    int pieceSockfd, piecePortno, pieceN;
    char pieceBuffer[BUFFER_SIZE];
    struct sockaddr_in pieceServ_addr;
    struct hostent *pieceSocket;
    // Création du socket de connection à la piece
    // piecePortno = MULTICAST_PORT;
    // pieceSockfd = socket(AF_INET, SOCK_DGRAM, 0);
    // if (pieceSockfd < 0)
    //     error("[CHAUFFAGE - ERROR] : Impossible de se connecter au multicast de la piece.\n");
    // pieceSocket = gethostbyname(MULTICAST_HOST);
    // if (pieceSocket == NULL)
    // { // Si l'ip n'est pas valide
    //     fprintf(stderr, "[CHAUFFAGE - ERROR] : L'adresse ip du multicast n'est pas valide.\n");
    //     exit(1);
    // }
    // bzero((char *)&pieceServ_addr, sizeof(pieceServ_addr));
    // pieceServ_addr.sin_family = AF_INET;
    // bcopy((char *)pieceSocket->h_addr, (char *)&pieceServ_addr.sin_addr.s_addr, pieceSocket->h_length);
    // pieceServ_addr.sin_port = htons(piecePortno);
    // // Pas de connection au niveau du client
    // if (connect(pieceSockfd, (struct sockaddr *)&pieceServ_addr, sizeof(pieceServ_addr)) < 0)
    //     error("[CHAUFFAGE - ERROR] : Impossible de se connecter au multicast.\n");

    if ((pieceSockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&pieceServ_addr, 0, sizeof(pieceServ_addr));
    // Filling server information
    pieceServ_addr.sin_family = AF_INET;
    pieceServ_addr.sin_port = htons(MULTICAST_PORT);
    pieceServ_addr.sin_addr.s_addr = INADDR_ANY;
    int n;
    socklen_t len;

    printf("[CHAUFFAGE - INFO] : Connection au multicast de la piece reussie...\n");

    //--- Tentative de connection au systeme de gestion de temperature ---//
    printf("[CHAUFFAGE - INFO] : Connection au systeme de gestion de temperature cours...\n");
    int systemeSockfd, systemePortno, systemeN;
    char systemeBuffer[BUFFER_SIZE];
    struct sockaddr_in systemeServ_addr;
    struct hostent *systemeSocket;
    // Création du socket de connection au systeme de gestion de temperature
    systemePortno = CHAUFFAGE_TO_SYSTEM_PORT;
    systemeSockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (systemeSockfd < 0)
        error("[CHAUFFAGE - ERROR] : Impossible de se connecter au systeme de gestion de temperature.\n");
    systemeSocket = gethostbyname("localhost");
    if (systemeSocket == NULL)
    { // Si l'ip n'est pas valide
        fprintf(stderr, "[CHAUFFAGE - ERROR] : L'adresse ip du systeme de gestion de temperature n'est pas valide.\n");
        exit(1);
    }

    bzero((char *)&systemeServ_addr, sizeof(systemeServ_addr));
    systemeServ_addr.sin_family = AF_INET;
    bcopy((char *)systemeSocket->h_addr, (char *)&systemeServ_addr.sin_addr.s_addr, systemeSocket->h_length);
    systemeServ_addr.sin_port = htons(systemePortno);
    // Pas de connection au niveau du client
    if (connect(systemeSockfd, (struct sockaddr *)&systemeServ_addr, sizeof(systemeServ_addr)) < 0)
        error("[CHAUFFAGE - CONNECT_ERROR] : Impossible de se connecter au systeme de gestion de temperature.\n");

    printf("[CHAUFFAGE - INFO] : Connection au systeme de gestion de temperature de la piece reussie...\n");

    // while loop for communication

    while (systemeSockfd < 0)
    {
        systemeN = read(systemeSockfd, systemeBuffer, BUFFER_SIZE);
        printf("[CHAUFFAGE - INFO] : %s\n", systemeBuffer);
        if (systemeN < 0)
            error("[CHAUFFAGE - ERROR] : Erreur lors de la lecture du message du module [COMMUNICATION_TEMPERATURE].\n");
        printf("Message : %s\n", systemeBuffer);
        // pieceN = write(pieceSockfd, systemeBuffer, BUFFER_SIZE);
        pieceN = sendto(pieceSockfd, (const char *)systemeBuffer, BUFFER_SIZE,
                        MSG_CONFIRM, (const struct sockaddr *)&pieceServ_addr,
                        sizeof(pieceServ_addr));
        if (pieceN < 0)
            error("[CHAUFFAGE - ERROR] : Erreur lors de l'envoie du message au module [PIECE].\n");
    }
    close(pieceSockfd);
    close(systemeSockfd);
    return 0;
}
