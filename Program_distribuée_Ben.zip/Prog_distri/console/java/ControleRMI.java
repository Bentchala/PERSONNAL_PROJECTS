package console.java;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import pack.java.Constants;

import systeme.java.metier.CtlInterface;

public class ControleRMI {
   
    private ControleRMI() {
    }

    /**
     * Point d'entrée principal du programme.
     * 
     * @param args Les arguments de la ligne de commande (non utilisés dans ce cas).
     */
    public static void main(String[] args) {
        try {
            //  RMI sur le serveur distant
            Registry registry = LocateRegistry.getRegistry(Constants.CLIENT_RMI_HOST, Constants.CLIENT_RMI_PORT);

            // Recherche de l'objet distant 
            CtlInterface stub = (CtlInterface) registry.lookup(Constants.CONNECTION_POINT);

            // Variable pour stocker le message récupéré du serveur
            String message = "";

            //  connexion réussie avec RMI
            System.out.println("[CONTROLE_RMI : INFO] : Connection etablie avec le module [SERVEUR_RMI].");

            /
            do {
                message = stub.printInformations();
                System.out.println(message);
            } while (message != null);

        } catch (Exception e) {
           
            System.err.println("[CONTROLE_RMI - RMI_ERROR] : " + e.getMessage());
        }
    }
}
