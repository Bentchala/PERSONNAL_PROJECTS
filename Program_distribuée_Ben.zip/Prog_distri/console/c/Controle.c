#include "../../pack/c/Console.h"

// Déclaration des variables globales pour la communication avec le module de gestion de température
int sockfd, portno, n;
char buffer[BUFFER_SIZE];
struct sockaddr_in serv_addr;
struct hostent *server;

int main()
{
    // Configuration du numéro de port
    portno = CONTROL_CONSOLE_PORT;

    // Création d'un socket pour la communication avec le module de gestion de température
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Vérification si la création du socket a réussi
    if (sockfd < 0)
        error("[CONTROLE_CONSOLE - SOCKET_ERROR] : Impossible de se connecter au module [GESTION_CONSOLE]\n");

    // Résolution du nom d'hôte (ici, "localhost") en adresse IP
    server = gethostbyname("localhost");

    // Vérification si la résolution a réussi
    if (server == NULL)
    {
        fprintf(stderr, "[CONTROLE_CONSOLE - SERVER_ERROR] : Hote non trouve...\n");
        exit(1);
    }

    // Initialisation de la structure sockaddr_in pour la connexion
    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);

    // Tentative de connexion au serveur
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        error("[CONTROLE_CONSOLE - CONNECTION_ERROR] : Impossible de se connecter au module [GESTION_CONSOLE]\n");

    // Affiche une confirmation de la connexion réussie
    printf("[CONTROLE_CONSOLE - INFO] : Connection etablie avec le module [GESTION_CONSOLE]\n");

    // Boucle de communication continue avec le serveur
    while (1)
    {
        printf("Reading...\n");

        // Lecture des données du socket dans le buffer
        n = read(sockfd, buffer, strlen(buffer));

        // Affiche le message reçu du serveur
        printf("Message : %s\n", buffer);

        // Vérification des erreurs de lecture
        if (n < 0)
            error("[CONTROLE_CONSOLE - READING_ERROR] : Impossible de lire les informations du module [GESTION_CONSOLE]\n");

        // Affiche le message reçu du serveur
        printf("-> %s\n", buffer);
    }

    
    close(sockfd);
    return 0;
}
