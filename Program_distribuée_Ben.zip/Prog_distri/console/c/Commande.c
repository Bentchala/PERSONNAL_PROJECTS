
#include "../../pack/c/Console.h"

// Fonction pour vérifier l'entrée utilisateur
int check_input(char *multicast, char mode, int level)
{
    // La condition suivante semble incorrecte, elle sera modifiée pour vérifier les valeurs correctes.
    return (mode != MODE_AUTOMATIC || mode != MODE_MANUAL || level < 0 || level > 5);
}

// Fonction principale
int main()
{
    // Déclaration des variables pour la connexion au serveur
    int sockfd, portno, n;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in serv_addr;
    struct hostent *server;

    // Initialisation du numéro de port
    portno = COMMAND_CONSOLE_PORT;

    // Création du socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Vérification si la création du socket a réussi
    if (sockfd < 0)
        error("[COMMANDE_CONSOLE - SOCKET_ERROR] : Impossible de se connecter au module [GESTION_CONSOLE]\n");

    // Résolution du nom d'hôte (ici, "localhost") en adresse IP
    server = gethostbyname("localhost");

    // Vérification si la résolution a réussi
    if (server == NULL)
    {
        fprintf(stderr, "[COMMANDE_CONSOLE - SERVER_ERROR] : Hote non trouve...\n");
        exit(1);
    }

    // Initialisation de la structure sockaddr_in pour la connexion
    bzero((char *)&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);

    // Tentative de connexion au serveur
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        error("[COMMANDE_CONSOLE - CONNECTION_ERROR] : Impossible de se connecter au module [GESTION_CONSOLE]\n\n");

    // Affichage d'informations sur la connexion réussie
    printf("[COMMANDE_CONSOLE - INFO] : Connection etablie avec le module [GESTION_CONSOLE]\n");
    printf("[COMMANDE_CONSOLE - INFO] : Pour modifier la temperature dans une piece, tapez dans l'ordre ces valeurs separees par un espace : \n");
    printf("[COMMANDE_CONSOLE - INFO] : (1) => L'adresse du groupe multicast de la piece (Ex : localhost) \n");
    printf("[COMMANDE_CONSOLE - INFO] : (2) => Mode de chauffage (A pour automatique / M pour manuel)\n");
    printf("[COMMANDE_CONSOLE - INFO] : (3) => Niveau de chauffage (De 0 a 5)\n");

    // Allocation dynamique d'une structure Information
    struct Information *info = malloc(sizeof(struct Information *));
    int level;
    int oneAttempt = FALSE;
    char mode;
    char mutlicast[MAX_MESSAGE_LENGTH];
    int one, two, three, four;

    /*
    Exemple de saisie : 224.0.0.1 M 2
    */

    // Boucle principale
    while (1)
    {
        oneAttempt = FALSE;
        do
        {
            // Si l'entrée utilisateur est incorrecte, affiche un message d'erreur
            if (oneAttempt)
            {
                printf("[COMMANDE_CONSOLE - SYNTHAX_ERROR] : Requete mal saisie. Reessayez...\n");
            }

            // Invite l'utilisateur à saisir des valeurs
            printf("> ");
            scanf("%d.%d.%d.%d %c %d", &one, &two, &three, &four, &mode, &level);

            // Formatage de l'adresse multicast
            snprintf(mutlicast, sizeof(char[MAX_MESSAGE_LENGTH]), "%d.%d.%d.%d", one, two, three, four);

            // Indique qu'il y a eu au moins une tentative d'entrée
            oneAttempt = TRUE;
        } while (level < 0 || level > 5);

        // Attribution des valeurs à la structure Information
        info->multicast = mutlicast;
        info->valeur = level;
        info->type = mode;

        // Conversion de la structure Information en chaîne de caractères
        char *message = p_info_parse(info);

        // Affiche le message généré
        printf("Message : %s\n", message);

        // Envoie du message au serveur
        n = write(sockfd, message, strlen(message));

        // Vérification si l'envoi a réussi
        if (n < 0)
            error("[COMMANDE_CONSOLE - WRITING_ERROR] : Erreur lors de l'envoie de la requete au module [GESTION_CONSOLE]\n");

        // Affiche une confirmation de l'envoi de la commande
        printf("[COMMANDE_CONSOLE - INFO] : Commande envoyee.\n");
    }

    // Libération de la mémoire allouée
    free(info);

    // Fermeture du socket
    close(sockfd);

    return 0;
}
/* connexion avec un serveur distant (module de gestion 
de température) via un socket 
Les entrées utilisateur sont vérifiées et envoyées au serveur de manière continue. 
*/